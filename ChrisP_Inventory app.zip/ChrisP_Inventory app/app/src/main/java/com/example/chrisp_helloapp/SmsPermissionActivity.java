package com.example.chrisp_helloapp;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

/**
 * Requests optional SMS permission. Denying permission never blocks inventory use.
 */
public class SmsPermissionActivity extends AppCompatActivity {

    public static final String PREFS_NAME = "inventory_preferences";
    public static final String KEY_PHONE = "sms_phone";
    public static final String KEY_SMS_ENABLED = "sms_enabled";

    private EditText phoneInput;
    private SharedPreferences preferences;

    private final ActivityResultLauncher<String> smsPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                preferences.edit().putBoolean(KEY_SMS_ENABLED, granted).apply();
                if (granted) {
                    savePhoneNumber();
                    Toast.makeText(this, "SMS alerts enabled", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "SMS alerts are off. Inventory will still work.", Toast.LENGTH_LONG).show();
                }
                openInventory();
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);

        preferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        phoneInput = findViewById(R.id.editPhoneNumber);
        Button allowButton = findViewById(R.id.button3);
        Button notNowButton = findViewById(R.id.button4);

        phoneInput.setText(preferences.getString(KEY_PHONE, ""));

        allowButton.setOnClickListener(v -> requestSmsPermission());
        notNowButton.setOnClickListener(v -> {
            preferences.edit().putBoolean(KEY_SMS_ENABLED, false).apply();
            openInventory();
        });
    }

    private void requestSmsPermission() {
        String phone = phoneInput.getText().toString().trim();
        if (TextUtils.isEmpty(phone)) {
            phoneInput.setError("Enter the phone number that should receive alerts");
            return;
        }
        savePhoneNumber();

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            preferences.edit().putBoolean(KEY_SMS_ENABLED, true).apply();
            openInventory();
        } else {
            smsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
        }
    }

    private void savePhoneNumber() {
        preferences.edit().putString(KEY_PHONE, phoneInput.getText().toString().trim()).apply();
    }

    private void openInventory() {
        Intent intent = new Intent(this, InventoryActivity.class);
        startActivity(intent);
        finish();
    }
}
