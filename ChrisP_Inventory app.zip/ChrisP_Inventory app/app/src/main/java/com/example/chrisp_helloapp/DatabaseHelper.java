package com.example.chrisp_helloapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Central SQLite helper for login credentials and persistent inventory data.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "inventory_tracking.db";
    private static final int DATABASE_VERSION = 1;

    public static final String TABLE_USERS = "users";
    public static final String TABLE_INVENTORY = "inventory";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_USERS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT UNIQUE NOT NULL, " +
                "password_hash TEXT NOT NULL)");

        db.execSQL("CREATE TABLE " + TABLE_INVENTORY + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "item_name TEXT NOT NULL, " +
                "quantity INTEGER NOT NULL DEFAULT 0 CHECK(quantity >= 0))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INVENTORY);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    /** Creates a user. Returns false when the username already exists. */
    public boolean createUser(String username, String password) {
        ContentValues values = new ContentValues();
        values.put("username", username.trim());
        values.put("password_hash", hashPassword(password));
        return getWritableDatabase().insert(TABLE_USERS, null, values) != -1;
    }

    /** Checks the supplied login against the users table. */
    public boolean validateLogin(String username, String password) {
        Cursor cursor = getReadableDatabase().query(
                TABLE_USERS,
                new String[]{"id"},
                "username = ? AND password_hash = ?",
                new String[]{username.trim(), hashPassword(password)},
                null, null, null
        );
        boolean valid = cursor.moveToFirst();
        cursor.close();
        return valid;
    }

    public Cursor getAllInventory() {
        return getReadableDatabase().query(
                TABLE_INVENTORY,
                new String[]{"id", "item_name", "quantity"},
                null, null, null, null,
                "item_name COLLATE NOCASE ASC"
        );
    }

    public long addItem(String itemName, int quantity) {
        ContentValues values = new ContentValues();
        values.put("item_name", itemName.trim());
        values.put("quantity", quantity);
        return getWritableDatabase().insert(TABLE_INVENTORY, null, values);
    }

    public boolean updateItem(long id, String itemName, int quantity) {
        ContentValues values = new ContentValues();
        values.put("item_name", itemName.trim());
        values.put("quantity", quantity);
        return getWritableDatabase().update(
                TABLE_INVENTORY, values, "id = ?", new String[]{String.valueOf(id)}) > 0;
    }

    public boolean updateQuantity(long id, int quantity) {
        ContentValues values = new ContentValues();
        values.put("quantity", Math.max(0, quantity));
        return getWritableDatabase().update(
                TABLE_INVENTORY, values, "id = ?", new String[]{String.valueOf(id)}) > 0;
    }

    public boolean deleteItem(long id) {
        return getWritableDatabase().delete(
                TABLE_INVENTORY, "id = ?", new String[]{String.valueOf(id)}) > 0;
    }

    private String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(password.getBytes(StandardCharsets.UTF_8));
            StringBuilder output = new StringBuilder();
            for (byte b : hash) {
                output.append(String.format("%02x", b));
            }
            return output.toString();
        } catch (NoSuchAlgorithmException e) {
            // SHA-256 is required by Android/Java; this fallback prevents a crash.
            return password;
        }
    }
}
