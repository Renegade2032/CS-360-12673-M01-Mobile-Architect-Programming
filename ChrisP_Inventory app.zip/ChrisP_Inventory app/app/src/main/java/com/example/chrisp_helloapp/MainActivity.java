package com.example.chrisp_helloapp;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/** Login and first-time account creation screen. */
public class MainActivity extends AppCompatActivity {

    private EditText usernameInput;
    private EditText passwordInput;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        databaseHelper = new DatabaseHelper(this);
        usernameInput = findViewById(R.id.editTextText);
        passwordInput = findViewById(R.id.editTextTextPassword);
        Button loginButton = findViewById(R.id.button5);
        Button createAccountButton = findViewById(R.id.button);

        loginButton.setOnClickListener(v -> login());
        createAccountButton.setOnClickListener(v -> createAccount());
    }

    private boolean inputsAreInvalid() {
        String username = usernameInput.getText().toString().trim();
        String password = passwordInput.getText().toString();

        if (TextUtils.isEmpty(username)) {
            usernameInput.setError("Enter a username");
            return true;
        }

        if (TextUtils.isEmpty(password)) {
            passwordInput.setError("Enter a password");
            return true;
        }

        if (password.length() < 4) {
            passwordInput.setError("Password must be at least 4 characters");
            return true;
        }

        return false;
    }

    private void login() {
        if (inputsAreInvalid()) return;

        String username = usernameInput.getText().toString().trim();
        String password = passwordInput.getText().toString();

        if (databaseHelper.validateLogin(username, password)) {
            Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();
            openSmsSetup();
        } else {
            Toast.makeText(this, "Incorrect username or password", Toast.LENGTH_SHORT).show();
        }
    }

    private void createAccount() {
        if (inputsAreInvalid()) return;

        String username = usernameInput.getText().toString().trim();
        String password = passwordInput.getText().toString();

        if (databaseHelper.createUser(username, password)) {
            Toast.makeText(this, "Account created. You can now log in.", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this, "That username already exists", Toast.LENGTH_LONG).show();
        }
    }

    private void openSmsSetup() {
        Intent intent = new Intent(this, SmsPermissionActivity.class);
        startActivity(intent);
    }
}
